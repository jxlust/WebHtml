## 安装导航路由

```shell
npm install @react-navigation/native react-native-screens react-native-safe-area-context @react-navigation/native-stack -S
npm install react-native-screens react-native-safe-area-context
npm install @react-navigation/native-stack  # 栈式导航
# 或添加其他导航器：
npm install @react-navigation/bottom-tabs  # 标签页导航
npm install @react-navigation/drawer
```

## 安卓环境配置

- 环境变量，写入 ~/.zshrc 文件

```shell
export JAVA_HOME=/Library/Java/JavaVirtualMachines/zulu-17.jdk/Contents/Home
export ANDROID_HOME=$HOME/Library/Android/sdk
export PATH=$PATH:$ANDROID_HOME/emulator
export PATH=$PATH:$ANDROID_HOME/platform-tools
```

> [参考链接](https://reactnative.dev/docs/set-up-your-environment)

- gradle 下载包镜像，修改 gradle/wrapper/gradle-wrapper.properties 文件

```json
distributionUrl=https\://mirrors.cloud.tencent.com/gradle/gradle-8.14.1-bin.zip
```

## RN 动画库
+ react-native-reanimated
+ react-native-worklets

## 注意事项

- ios 下更新了依赖，命令用于在 React Native 项目中安装或更新 CocoaPods 依赖。CocoaPods 是一个用于管理和维护 Objective-C/Cocoa 项目的外部库的包管理工具，常用于 iOS 开发。`npx pod-install ios`

```shell
npx pod install：这是一个常见的等价命令，作用相同。
npx pod update：用来更新所有依赖库到Podfile中指定的版本。
npx pod check：用来验证Podfile中的依赖关系是否正确。
```

通过这些命令，你可以有效地管理你的 React Native 项目的 iOS 部分的依赖关系。
