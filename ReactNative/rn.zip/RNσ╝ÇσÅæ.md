## 安装导航路由
```shell
npm install @react-navigation/native react-native-screens react-native-safe-area-context @react-navigation/native-stack -S
npm install react-native-screens react-native-safe-area-context
npm install @react-navigation/native-stack  # 栈式导航
# 或添加其他导航器：
npm install @react-navigation/bottom-tabs  # 标签页导航
npm install @react-navigation/drawer 
```