import { createNativeStackNavigator } from '@react-navigation/native-stack';
import HomeScreen from '../screens/HomeScreen';
import DetailsScreen from '../screens/DetailsScreen';

// 步骤1：定义路由参数类型（关键！）
export type RootStackParamList = {
  Home: undefined; // 无参数
  Details: { id: string; title?: string }; // 动态参数
};

const Stack = createNativeStackNavigator<RootStackParamList>();

function RootStack() {
  return (
    <Stack.Navigator
      initialRouteName="Home"
      screenOptions={{ headerTitleAlign: 'center' }}
    >
      <Stack.Screen
        name="Home"
        component={HomeScreen}
        options={{
          headerTitle: '首页', // 设置标题
        }}
      />
      <Stack.Screen
        name="Details"
        component={DetailsScreen}
        options={({ route }) => ({ title: route.params.title })} // 动态标题
      />
    </Stack.Navigator>
  );
}
export default RootStack;
