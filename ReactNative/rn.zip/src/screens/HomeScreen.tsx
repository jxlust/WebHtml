// 在HomeScreen中跳转
import { useNavigation } from '@react-navigation/native';
import { RootStackParamList } from '../navigators/RootStack';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Button } from 'react-native';

type HomeScreenProp = NativeStackNavigationProp<RootStackParamList, 'Home'>;

function HomeScreen() {
  const navigation = useNavigation<HomeScreenProp>();

  return (
    <Button
      title="Go to Details"
      onPress={() => navigation.navigate('Details', { id: '123' })}
    />
  );
}
