// 在HomeScreen中跳转
import { useNavigation } from '@react-navigation/native';
import { RootStackParamList } from '../navigators/RootStack';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Button, StyleSheet, View } from 'react-native';
import Animated, {
  interpolate,
  useAnimatedRef,
  useAnimatedStyle,
  useScrollOffset,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
type HomeScreenProp = NativeStackNavigationProp<RootStackParamList, 'Home'>;

const HEADER_HEIGHT = 250;
function HomeScreen() {
  const navigation = useNavigation<HomeScreenProp>();
  const scrollRef = useAnimatedRef<Animated.ScrollView>();
  const scrollOffset = useScrollOffset(scrollRef);
  const bottom = 0;

  const headerAnimatedStyle = useAnimatedStyle(() => {
    return {
      transform: [
        {
          translateY: interpolate(
            scrollOffset.value,
            [-HEADER_HEIGHT, 0, HEADER_HEIGHT],
            [-HEADER_HEIGHT / 2, 0, HEADER_HEIGHT * 0.75],
          ),
        },
        {
          scale: interpolate(
            scrollOffset.value,
            [-HEADER_HEIGHT, 0, HEADER_HEIGHT],
            [2, 1, 1],
          ),
        },
      ],
    };
  });

  const btnWidth = useSharedValue(100);

  const handleBtnPress = () => {
    // btnWidth.value = btnWidth.value + 50;
    console.log(btnWidth.value);
    btnWidth.value = withSpring(btnWidth.value + 50);
  };
  return (
    <Animated.ScrollView
      ref={scrollRef}
      scrollEventThrottle={16}
      scrollIndicatorInsets={{ bottom }}
      contentContainerStyle={{ paddingBottom: bottom }}
    >
      <Animated.View
        style={[
          styles.header,
          { backgroundColor: '#A1CEDC' },
          headerAnimatedStyle,
        ]}
      ></Animated.View>
      <Button
        title="Go to Details"
        onPress={() =>
          navigation.navigate('Details', { title: '详情页', id: '123' })
        }
      />
      <View style={styles.boxContainer}>
        <Animated.View
          style={{
            ...styles.box,
            width: btnWidth,
          }}
        />
        <Button onPress={handleBtnPress} title="Click me" />
      </View>
    </Animated.ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    height: HEADER_HEIGHT,
    overflow: 'hidden',
  },
  content: {
    flex: 1,
    padding: 32,
    gap: 16,
    overflow: 'hidden',
  },
  boxContainer: {
    flex: 1,
    alignContent: 'center',
    alignItems: 'center',
    // justifyContent: 'center',
  },
  box: {
    height: 100,
    backgroundColor: '#b58df1',
    borderRadius: 20,
    marginVertical: 64,
  },
});
export default HomeScreen;
