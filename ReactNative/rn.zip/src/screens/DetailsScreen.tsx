// 在DetailsScreen中获取参数
import { RouteProp } from '@react-navigation/native';
import { Text } from 'react-native';
import { RootStackParamList } from '../navigators/RootStack';

type DetailsRouteProp = RouteProp<RootStackParamList, 'Details'>;

function DetailsScreen({ route }: { route: DetailsRouteProp }) {
  const { id, title } = route.params;
  return <Text>ID: {id}</Text>;
}
