function test1() {
    console.log('test 1');
}
test1();